package org.codehaus.groovy.grails.plugins.yui;

class Yui {

    static version = "2.7.0"

}
