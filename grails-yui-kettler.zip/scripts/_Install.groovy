Ant.property(environment:"env")
grailsHome = Ant.antProject.properties."env.GRAILS_HOME"

includeTargets << grailsScript("Init")
checkVersion()
configureProxy()

downloadDir = new File(grailsWorkDir, "download")
downloadPath = downloadDir.absolutePath

yuiVersion = "2.7.0"

Ant.sequential {
    mkdir(dir:"${downloadDir}")

    event("StatusUpdate", ["Downloading YUI ${yuiVersion}"])

    println "Denoncout says NO to: Getting YUI from: http://downloads.sourceforge.net/yui/yui_${yuiVersion}.zip"
/*
    get(dest:"${downloadDir}/yui_${yuiVersion}.zip",
        src:"http://developer.yahoo.com/yui/download/",
        verbose:true,
        usetimestamp:true)
    unzip(dest:"${downloadDir}/yui_${yuiVersion}",
        src:"${downloadDir}/yui_${yuiVersion}.zip")

    mkdir(dir:"${basedir}/web-app/js/yui/${yuiVersion}")
    copy(todir:"${basedir}/web-app/js/yui/${yuiVersion}") {
        fileset(dir:"${downloadDir}/yui_${yuiVersion}/yui/build", includes:"** / **") denoncourt added spaces to stop the comment from ending
    }
*/
}
event("StatusFinal", ["YUI ${yuiVersion} installed successfully"])
